import{Y as a}from"./vendor-DW_s8V88.js";import{ad as m}from"./index-hv_j-1W6.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
